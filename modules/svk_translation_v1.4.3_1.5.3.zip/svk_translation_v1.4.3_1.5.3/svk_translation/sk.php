<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{svk_translation}prestashop>svk_translation_35dfd408cc5110e074c8e415decc7120'] = 'Slovenský preklad DB';
$_MODULE['<{svk_translation}prestashop>svk_translation_c7fdacd3cdae26a4ea1ab844531cd133'] = 'Tento modul prekladá databázové položky do Slovenského jazkyka';
